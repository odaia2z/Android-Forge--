package dev.androidforge.platform;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public final class ProjectDatabase extends SQLiteOpenHelper {
    public static final class Project {
        public String id,name,kind; public long created,modified; public int files; public long bytes;
    }
    public ProjectDatabase(Context context){super(context,"project-index.db",null,1);}
    public void onCreate(SQLiteDatabase db){db.execSQL("CREATE TABLE projects (id TEXT PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL, created INTEGER, modified INTEGER, files INTEGER DEFAULT 0, bytes INTEGER DEFAULT 0)");}
    public void onUpgrade(SQLiteDatabase db,int old,int next){throw new IllegalStateException("Migration required; destructive upgrades are forbidden");}
    public synchronized void add(String id,String name,String kind){ContentValues v=new ContentValues();v.put("id",id);v.put("name",name);v.put("kind",kind);v.put("created",System.currentTimeMillis());v.put("modified",System.currentTimeMillis());getWritableDatabase().insertOrThrow("projects",null,v);}
    public synchronized void touch(String id){ContentValues v=new ContentValues();v.put("modified",System.currentTimeMillis());getWritableDatabase().update("projects",v,"id=?",new String[]{id});}
    public synchronized void index(String id,int files,long bytes,String kind){ContentValues v=new ContentValues();v.put("files",files);v.put("bytes",bytes);v.put("kind",kind);getWritableDatabase().update("projects",v,"id=?",new String[]{id});}
    public synchronized void remove(String id){getWritableDatabase().delete("projects","id=?",new String[]{id});}
    public synchronized List<Project> all(){List<Project> list=new ArrayList<>();try(Cursor c=getReadableDatabase().query("projects",null,null,null,null,null,"modified DESC")){while(c.moveToNext()){Project p=new Project();p.id=c.getString(c.getColumnIndexOrThrow("id"));p.name=c.getString(c.getColumnIndexOrThrow("name"));p.kind=c.getString(c.getColumnIndexOrThrow("kind"));p.created=c.getLong(c.getColumnIndexOrThrow("created"));p.modified=c.getLong(c.getColumnIndexOrThrow("modified"));p.files=c.getInt(c.getColumnIndexOrThrow("files"));p.bytes=c.getLong(c.getColumnIndexOrThrow("bytes"));list.add(p);}}return list;}
    public Project get(String id){for(Project p:all())if(p.id.equals(id))return p;return null;}
}
