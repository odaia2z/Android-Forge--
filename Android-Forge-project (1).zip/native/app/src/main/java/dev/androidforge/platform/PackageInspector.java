package dev.androidforge.platform;

import android.content.pm.*;
import dev.androidforge.core.*;
import java.io.*;
import java.security.MessageDigest;
import java.util.*;

public final class PackageInspector {
    public static String inspect(PackageManager manager,File archive,boolean aab)throws Exception{
        Archives.Inventory i=Archives.inspect(archive);StringBuilder out=new StringBuilder();
        out.append(aab?"AAB ARCHIVE\n":"APK ARCHIVE\n");
        out.append("Entries: ").append(i.entries).append("\nUncompressed size: ").append(Analyzer.humanBytes(i.uncompressed)).append("\nResource entries: ").append(i.resources).append("\nDEX files: ").append(i.dexFiles).append("\nDEX class definitions: ").append(i.dexClasses).append("\nDEX method references: ").append(i.dexMethods).append("\nModules: ").append(String.join(", ",i.modules)).append("\nABIs: ").append(String.join(", ",i.abis)).append("\nManifests: ").append(String.join(", ",i.manifests)).append("\n");
        if(!aab){
            int flags=PackageManager.GET_PERMISSIONS|PackageManager.GET_ACTIVITIES|PackageManager.GET_SERVICES|PackageManager.GET_RECEIVERS|PackageManager.GET_PROVIDERS|PackageManager.GET_SIGNING_CERTIFICATES;
            PackageInfo info=manager.getPackageArchiveInfo(archive.getAbsolutePath(),flags);
            if(info==null)out.append("\nAndroid PackageManager could not parse package metadata. This is not proof of a valid APK.\n");
            else {
                out.append("\nPACKAGE\n").append(info.packageName).append("\nVersion: ").append(info.versionName).append("\nVersion code: ").append(info.getLongVersionCode());
                if(info.applicationInfo!=null)out.append("\nMinimum SDK: ").append(info.applicationInfo.minSdkVersion).append("\nTarget SDK: ").append(info.applicationInfo.targetSdkVersion);
                out.append("\n\nPERMISSIONS\n");if(info.requestedPermissions!=null)for(String p:info.requestedPermissions)out.append(p).append('\n');
                append(out,"ACTIVITIES",info.activities);append(out,"SERVICES",info.services);append(out,"RECEIVERS",info.receivers);append(out,"PROVIDERS",info.providers);
                if(info.signingInfo!=null){out.append("\nSIGNER CERTIFICATE SHA-256 (not a trust verdict)\n");for(Signature signature:info.signingInfo.getApkContentsSigners()){byte[] digest=MessageDigest.getInstance("SHA-256").digest(signature.toByteArray());for(byte b:digest)out.append(String.format(Locale.ROOT,"%02X",b));out.append('\n');}}
            }
        }
        out.append("\nMETA-INF ENTRIES (not cryptographic verification)\n");for(String signature:i.signatures)out.append(signature).append('\n');
        return out.toString();
    }
    private static void append(StringBuilder out,String label,ComponentInfo[] components){out.append("\n").append(label).append("\n");if(components!=null)for(ComponentInfo c:components)out.append(c.name).append(" · exported=").append(c.exported).append('\n');}
}
