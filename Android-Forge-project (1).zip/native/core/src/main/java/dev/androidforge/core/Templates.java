package dev.androidforge.core;

import java.io.*;
import java.nio.charset.StandardCharsets;

public final class Templates {
    private Templates() {}
    public static void create(File root,String name,String pkg,String language,String ui,int min,int target) throws IOException {
        if(name.trim().isEmpty()||name.length()>80||!pkg.matches("[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+")) throw new IOException("Use a valid application name and lowercase package, such as com.example.app");
        if(min<29||min>target||target>35) throw new IOException("Choose 29 ≤ minSdk ≤ targetSdk ≤ 35");
        if(ui.equals("Web")) {web(root,name);return;}
        boolean kotlin=language.equals("Kotlin"),compose=ui.equals("Compose");
        if(compose&&!kotlin) throw new IOException("Compose template requires Kotlin");
        put(root,"settings.gradle","pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }\nrootProject.name = '"+name.replaceAll("[^a-zA-Z0-9_-]","_")+"'\ninclude ':app'\n");
        put(root,"build.gradle","plugins {\n    id 'com.android.application' version '8.7.3' apply false\n"+(kotlin?"    id 'org.jetbrains.kotlin.android' version '2.0.21' apply false\n":"")+(compose?"    id 'org.jetbrains.kotlin.plugin.compose' version '2.0.21' apply false\n":"")+"}\n");
        put(root,"gradle.properties","android.useAndroidX=true\norg.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\n");
        put(root,"app/build.gradle","plugins {\n    id 'com.android.application'\n"+(kotlin?"    id 'org.jetbrains.kotlin.android'\n":"")+(compose?"    id 'org.jetbrains.kotlin.plugin.compose'\n":"")+"}\nandroid {\n    namespace '"+pkg+"'\n    compileSdk 35\n    defaultConfig {\n        applicationId '"+pkg+"'\n        minSdk "+min+"\n        targetSdk "+target+"\n        versionCode 1\n        versionName '1.0'\n    }\n    compileOptions { sourceCompatibility JavaVersion.VERSION_17; targetCompatibility JavaVersion.VERSION_17 }\n"+(kotlin?"    kotlinOptions { jvmTarget = '17' }\n":"")+(compose?"    buildFeatures { compose true }\n":"")+"}\n"+(compose?"dependencies {\n    implementation platform('androidx.compose:compose-bom:2024.12.01')\n    implementation 'androidx.activity:activity-compose:1.9.3'\n    implementation 'androidx.compose.material3:material3'\n    implementation 'androidx.compose.ui:ui'\n}\n":""));
        put(root,"app/src/main/AndroidManifest.xml","<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\">\n    <application android:label=\"@string/app_name\" android:theme=\"@android:style/Theme.Material.Light.NoActionBar\" android:allowBackup=\"false\" android:supportsRtl=\"true\">\n        <activity android:name=\".MainActivity\" android:exported=\"true\">\n            <intent-filter>\n                <action android:name=\"android.intent.action.MAIN\" />\n                <category android:name=\"android.intent.category.LAUNCHER\" />\n            </intent-filter>\n        </activity>\n    </application>\n</manifest>\n");
        put(root,"app/src/main/res/values/strings.xml","<resources>\n    <string name=\"app_name\">"+escape(name).replace("'","\\'")+"</string>\n    <string name=\"welcome\">Hello from Android Forge</string>\n</resources>\n");
        String folder="app/src/main/java/"+pkg.replace('.','/')+"/";
        if(compose) put(root,folder+"MainActivity.kt","package "+pkg+"\n\nimport android.os.Bundle\nimport androidx.activity.ComponentActivity\nimport androidx.activity.compose.setContent\nimport androidx.compose.material3.*\n\nclass MainActivity : ComponentActivity() {\n    override fun onCreate(savedInstanceState: Bundle?) {\n        super.onCreate(savedInstanceState)\n        setContent { MaterialTheme { Surface { Text(\"Hello from Android Forge\") } } }\n    }\n}\n");
        else {
            put(root,"app/src/main/res/layout/activity_main.xml","<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\" android:orientation=\"vertical\" android:gravity=\"center\">\n    <TextView android:layout_width=\"wrap_content\" android:layout_height=\"wrap_content\" android:text=\"@string/welcome\" android:textSize=\"24sp\" />\n</LinearLayout>\n");
            put(root,folder+"MainActivity."+(kotlin?"kt":"java"),kotlin?"package "+pkg+"\n\nimport android.app.Activity\nimport android.os.Bundle\n\nclass MainActivity : Activity() {\n    override fun onCreate(savedInstanceState: Bundle?) {\n        super.onCreate(savedInstanceState)\n        setContentView(R.layout.activity_main)\n    }\n}\n":"package "+pkg+";\n\nimport android.app.Activity;\nimport android.os.Bundle;\n\npublic class MainActivity extends Activity {\n    @Override public void onCreate(Bundle state) {\n        super.onCreate(state);\n        setContentView(R.layout.activity_main);\n    }\n}\n");
        }
        put(root,".gitignore",".gradle/\nlocal.properties\n**/build/\n.idea/\n");
        put(root,"README.md","# "+name+"\n\nCreated with Android Forge. Open this directory in Android Studio. Install JDK 17 and Android SDK 35, then run `sh gradlew assembleDebug` (first build downloads Gradle and dependencies).\n\nImported build scripts are executable code: review them before building. No build was performed on the phone.\n");
    }
    private static void web(File root,String name) throws IOException {
        put(root,"index.html","<!doctype html>\n<html lang=\"en\"><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><link rel=\"stylesheet\" href=\"style.css\"><title>"+escape(name)+"</title></head>\n<body><main><p class=\"eyebrow\">BUILT WITH ANDROID FORGE</p><h1>"+escape(name)+"</h1><p>Your mobile web project starts here.</p><button id=\"counter\">Tap to interact</button><p id=\"result\" aria-live=\"polite\"></p></main><script src=\"app.js\"></script></body></html>\n");
        put(root,"style.css",":root{font-family:system-ui;color:#eff7f3;background:#0c1220}body{margin:0;min-height:100vh;display:grid;place-items:center}main{padding:32px;max-width:500px}h1{font-size:40px;letter-spacing:-1.5px}.eyebrow{font-size:11px;letter-spacing:3px;color:#65dcac}p{line-height:1.7;color:#a1afbf}button{background:#65dcac;border:0;border-radius:12px;padding:16px 24px;font:600 16px system-ui;color:#0c1220}button:active{opacity:.8}\n");
        put(root,"app.js","let taps = 0;\ndocument.querySelector('#counter').addEventListener('click', () => {\n  taps += 1;\n  document.querySelector('#result').textContent = `You tapped ${taps} time${taps === 1 ? '' : 's'}.`;\n});\n");
        put(root,"README.md","# "+name+"\n\nLocal HTML/CSS/JavaScript project. Open index.html in Android Forge Preview. JavaScript requires an explicit session confirmation. External network access is disabled.\n");
    }
    public static String fileTemplate(String kind,String name,String pkg) throws IOException {
        String bare=name.replaceAll("\\.[^.]+$","");
        if(!bare.matches("[A-Za-z_][A-Za-z0-9_]*")&&!kind.equals("Generic")) throw new IOException("Use a valid identifier for this template");
        String packageLine=pkg.isEmpty()?"":"package "+pkg;
        if(!pkg.isEmpty()&&!pkg.matches("[a-zA-Z_]\\w*(\\.[a-zA-Z_]\\w*)*")) throw new IOException("Invalid package");
        switch(kind) {
            case "Kotlin Class":return packageLine+"\n\nclass "+bare+" {\n}\n";
            case "Java Class":return (packageLine.isEmpty()?"":packageLine+";\n\n")+"public class "+bare+" {\n}\n";
            case "Activity":return packageLine+"\n\nimport android.app.Activity\nimport android.os.Bundle\n\nclass "+bare+" : Activity() {\n    override fun onCreate(state: Bundle?) {\n        super.onCreate(state)\n    }\n}\n";
            case "Fragment":return packageLine+"\n\nimport androidx.fragment.app.Fragment\n\nclass "+bare+" : Fragment()\n";
            case "Compose Screen":return packageLine+"\n\nimport androidx.compose.runtime.Composable\nimport androidx.compose.material3.Text\n\n@Composable\nfun "+bare+"() {\n    Text(\"Hello\")\n}\n";
            case "Interface":return packageLine+"\n\ninterface "+bare+" {\n}\n";
            case "Data Class":return packageLine+"\n\ndata class "+bare+"(val id: String)\n";
            case "XML Layout":return "<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\" android:orientation=\"vertical\">\n</LinearLayout>\n";
            case "JSON":return "{\n}\n";
            case "Resource":return "<resources>\n</resources>\n";
            case "JavaScript":case "TypeScript":return "// "+bare+"\n";
            default:return "";
        }
    }
    private static String escape(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}
    private static void put(File root,String path,String text)throws IOException{SafeFiles.atomicWrite(SafeFiles.resolve(root,path),text.getBytes(StandardCharsets.UTF_8));}
}
