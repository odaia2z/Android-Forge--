import {EditorView, basicSetup} from 'codemirror';
import {EditorState, Compartment} from '@codemirror/state';
import {keymap} from '@codemirror/view';
import {indentWithTab, undo, redo} from '@codemirror/commands';
import {openSearchPanel, gotoLine} from '@codemirror/search';
import {StreamLanguage} from '@codemirror/language';
import {kotlin} from '@codemirror/legacy-modes/mode/clike';
import {groovy} from '@codemirror/legacy-modes/mode/groovy';
import {shell} from '@codemirror/legacy-modes/mode/shell';
import {java} from '@codemirror/lang-java';
import {javascript} from '@codemirror/lang-javascript';
import {xml} from '@codemirror/lang-xml';
import {json} from '@codemirror/lang-json';
import {html} from '@codemirror/lang-html';
import {css} from '@codemirror/lang-css';
import {markdown} from '@codemirror/lang-markdown';
import {oneDark} from '@codemirror/theme-one-dark';
import {MergeView} from '@codemirror/merge';

let current='', dark=true, editor=null, merge=null;
const sessions=new Map();
function language(path){const ext=path.split('.').pop().toLowerCase();if(ext==='kt'||ext==='kts')return StreamLanguage.define(kotlin);if(ext==='gradle')return StreamLanguage.define(groovy);if(ext==='sh'||path.endsWith('gradlew'))return StreamLanguage.define(shell);if(ext==='java')return java();if(['js','jsx','ts','tsx'].includes(ext))return javascript({typescript:ext.startsWith('ts'),jsx:ext.endsWith('x')});if(['xml','svg'].includes(ext))return xml();if(ext==='json')return json();if(ext==='html')return html();if(ext==='css')return css();if(ext==='md')return markdown();return [];}
function notify(){if(!editor)return;try{window.Forge?.changed(current,editor.state.doc.toString());}catch(e){console.error(e);}}
function state(path,text){return EditorState.create({doc:text,extensions:[basicSetup,language(path),...(dark?[oneDark]:[]),EditorView.theme({'&':{height:'100%',backgroundColor:dark?'#101827':'#fff',fontSize:'13px'},'.cm-scroller':{overflow:'auto',fontFamily:'monospace'},'.cm-content':{padding:'14px 0'},'.cm-gutters':{backgroundColor:dark?'#101827':'#f3f5f8',border:'none'},'.cm-activeLine':{backgroundColor:dark?'#1b2a40':'#edf3fa'}}),keymap.of([{key:'Mod-s',run:()=>{window.Forge?.saveRequested();return true;}},indentWithTab]),EditorView.updateListener.of(update=>{if(update.docChanged)notify();if(update.selectionSet||update.docChanged){let s=update.state.selection.main, line=update.state.doc.lineAt(s.head);document.querySelector('#position').textContent=`Ln ${line.number}, Col ${s.head-line.from+1} · UTF-8`;}})]});}
function open(payload){dark=payload.dark;document.body.style.background=dark?'#101827':'#fff';document.body.style.color=dark?'#92a1b5':'#607084';if(merge){merge.destroy();merge=null;document.querySelector('#merge').style.display='none';document.querySelector('#editor').style.display='block';}if(editor&&current)sessions.set(current,editor.state);current=payload.path;const cached=sessions.get(current);const next=cached&&cached.doc.toString()===payload.text?cached:state(current,payload.text);if(editor)editor.setState(next);else editor=new EditorView({state:next,parent:document.querySelector('#editor')});if(payload.line>0){const line=editor.state.doc.line(Math.min(payload.line,editor.state.doc.lines));editor.dispatch({selection:{anchor:line.from},scrollIntoView:true});}document.querySelector('#mode').textContent=current.split('.').pop().toUpperCase();}
function action(name,value){if(!editor)return;if(name==='undo')undo(editor);if(name==='redo')redo(editor);if(name==='find')openSearchPanel(editor);if(name==='line')gotoLine(editor);if(name==='format'){try{const pretty=JSON.stringify(JSON.parse(editor.state.doc.toString()),null,2)+'\n';editor.dispatch({changes:{from:0,to:editor.state.doc.length,insert:pretty}});}catch(e){window.Forge?.error(String(e.message));}}if(name==='insert')editor.dispatch(editor.state.replaceSelection(value));if(name==='focus')editor.focus();}
function compare(payload){if(merge)merge.destroy();document.querySelector('#editor').style.display='none';document.querySelector('#merge').style.display='block';const ext=[basicSetup,EditorState.readOnly.of(true),EditorView.editable.of(false),...(dark?[oneDark]:[])];merge=new MergeView({a:{doc:payload.old,extensions:ext},b:{doc:payload.current,extensions:ext},parent:document.querySelector('#merge'),collapseUnchanged:{margin:3,minSize:5},highlightChanges:true,gutter:true});}
window.editorApi={open,action,compare,ready:true};
window.Forge?.ready();
