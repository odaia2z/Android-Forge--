package dev.androidforge.core;

import java.io.File;
import java.util.List;

/** Provider boundary for a future audited, isolated build runtime. */
public interface BuildEngine {
    enum Task { DEBUG_APK, RELEASE_APK, RELEASE_AAB, CLEAN, REBUILD }
    boolean available();
    String reason();
    Result execute(File project,Task task) throws Exception;
    final class Result {
        public final boolean success; public final List<String> logs; public final File artifact;
        public Result(boolean success,List<String> logs,File artifact){this.success=success;this.logs=logs;this.artifact=artifact;}
    }
    final class Unavailable implements BuildEngine {
        public boolean available(){return false;}
        public String reason(){return "No isolated Gradle/JDK/Android SDK build provider is installed in this release. Export the project and build it with Android Studio. No imported scripts have been executed.";}
        public Result execute(File project,Task task){throw new UnsupportedOperationException(reason());}
    }
}
