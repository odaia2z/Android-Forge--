package dev.androidforge.core;

import java.io.*;
import java.util.*;
import java.util.regex.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.*;

public final class Analyzer {
    public static final class Problem {
        public final String severity,path,message,explanation,suggestion; public final int line;
        public Problem(String severity,String path,int line,String message,String explanation,String suggestion) { this.severity=severity;this.path=path;this.line=line;this.message=message;this.explanation=explanation;this.suggestion=suggestion; }
    }
    public static final class Dependency {
        public final String configuration,coordinate,path; public final int line;
        public Dependency(String c,String v,String p,int l){configuration=c;coordinate=v;path=p;line=l;}
    }
    public static final class Report {
        public final Map<String,String> fields=new LinkedHashMap<>();
        public final List<String> permissions=new ArrayList<>(),activities=new ArrayList<>(),services=new ArrayList<>(),receivers=new ArrayList<>(),providers=new ArrayList<>();
        public final List<Dependency> dependencies=new ArrayList<>(); public final List<Problem> problems=new ArrayList<>();
        public int files,modules,kotlin,java,xml,skipped; public long bytes;
        public String manifest="",gradle="",webEntry=""; public boolean compose,web,reactNative;
        public int errors(){return (int)problems.stream().filter(p->p.severity.equals("Error")||p.severity.equals("Critical")).count();}
        public int warnings(){return (int)problems.stream().filter(p->p.severity.equals("Warning")).count();}
    }
    public Report analyze(File root) throws IOException {
        Report report=new Report(); List<File> files=new ArrayList<>(); collect(root,root,files,report,0);
        List<File> manifests=new ArrayList<>();
        for(File file:files) {
            String path=SafeFiles.relative(root,file), name=file.getName();
            if(name.equals("AndroidManifest.xml")) manifests.add(file);
            if(name.equals("index.html")&&(report.webEntry.isEmpty()||path.length()<report.webEntry.length())) {report.webEntry=path;report.web=true;}
            if(name.equals("build.gradle")||name.equals("build.gradle.kts")) {
                try { parseGradle(SafeFiles.text(file),path,report); } catch(IOException e) { report.skipped++; }
            }
            if(name.equals("gradle-wrapper.properties")) try { String t=SafeFiles.text(file); putMatch(report,"Gradle",t,"gradle-([0-9.]+)-(?:bin|all)\\.zip"); } catch(IOException ignored){report.skipped++;}
            if(name.equals("package.json")) try { String t=SafeFiles.text(file); report.reactNative|=t.contains("\"expo\"")||t.contains("\"react-native\""); report.web|=t.contains("\"vite\""); }catch(IOException ignored){report.skipped++;}
            if(name.endsWith(".kt")) try { if(SafeFiles.text(file).contains("@Composable")) report.compose=true; }catch(IOException ignored){report.skipped++;}
            if(name.endsWith(".xml")&&!name.equals("AndroidManifest.xml")&&file.length()<=SafeFiles.MAX_TEXT) try { xml(SafeFiles.text(file)); } catch(Exception e) { report.problems.add(new Problem("Error",path,line(e),"Invalid XML",e.getMessage(),"Correct the XML syntax and analyze again.")); }
            if(path.matches(".*res/(drawable|mipmap|layout|raw|font)(-[^/]+)?/[^/]+")&&!name.matches("[a-z0-9_]+(\\.[a-z0-9.]+)?")) report.problems.add(new Problem("Warning",path,1,"Invalid Android resource name","Android resource filenames use lowercase letters, digits and underscores.","Rename this file using lowercase characters."));
        }
        manifests.sort(Comparator.comparing((File f)->!SafeFiles.relative(root,f).contains("src/main/")).thenComparingInt(f->f.getPath().length()));
        if(!manifests.isEmpty()) { report.manifest=SafeFiles.relative(root,manifests.get(0)); try { parseManifest(SafeFiles.text(manifests.get(0)),report.manifest,report); }catch(Exception e){report.problems.add(new Problem("Error",report.manifest,line(e),"Invalid AndroidManifest",e.getMessage(),"Open the manifest and correct its XML structure."));} }
        else if(!report.web&&!report.reactNative) report.problems.add(new Problem("Warning","",1,"No AndroidManifest found","This may be a partial project or a non-Android source folder.","Import the complete Android project."));
        if(!report.manifest.isEmpty()&&report.gradle.isEmpty()) report.problems.add(new Problem("Warning","",1,"No Android Gradle module found","The analyzer did not find a literal Android application plugin.","Inspect build files or export to Android Studio; version-catalog aliases are not resolved."));
        if(report.fields.getOrDefault("App name","").startsWith("@string/")) {
            String resource=report.fields.get("App name").substring(8);
            for(File f:files) if(f.getPath().endsWith("res/values/strings.xml")) try { NodeList nodes=xml(SafeFiles.text(f)).getElementsByTagName("string"); for(int i=0;i<nodes.getLength();i++) {Element el=(Element)nodes.item(i);if(resource.equals(el.getAttribute("name"))) report.fields.put("App name",el.getTextContent());} }catch(Exception ignored){}
        }
        report.fields.put("Language",report.kotlin>0?(report.java>0?"Kotlin + Java":"Kotlin"):(report.java>0?"Java":(report.web||report.reactNative?"JavaScript / TypeScript":"Unknown")));
        report.fields.put("UI",report.compose?"Jetpack Compose":(!report.manifest.isEmpty()?"XML / native":(report.reactNative?"React Native / Expo":report.web?"Mobile Web":"Unknown")));
        report.fields.put("Files",String.valueOf(report.files)); report.fields.put("Modules (detected)",String.valueOf(report.modules));
        report.fields.put("Size",humanBytes(report.bytes));
        int min=number(report.fields.get("Min SDK"));
        report.fields.put("Android 10 / API 29",min==0?"Unknown — minSdk not resolved":min<=29?"minSdk permits installation; runtime/API checks not performed":"Not installable: minSdk > 29");
        if(report.reactNative&&report.webEntry.isEmpty()) report.problems.add(new Problem("Info","package.json",1,"Web export required for preview","Expo / React Native source is not directly executable as HTML.","Export the web build on a trusted desktop, then import its dist directory."));
        if(report.skipped>0) report.problems.add(new Problem("Info","",1,"Some files were not inspected",report.skipped+" files exceeded text limits or could not be decoded.","Review large or binary files with appropriate tools."));
        return report;
    }
    private void collect(File root,File dir,List<File> files,Report r,int depth) throws IOException {
        if(depth>64) throw new IOException("Directory nesting exceeds safety limit");
        for(File f:SafeFiles.children(dir)) { SafeFiles.resolve(root,SafeFiles.relative(root,f)); if(f.isDirectory()) collect(root,f,files,r,depth+1); else {if(++r.files>SafeFiles.MAX_ENTRIES) throw new IOException("Project entry limit");r.bytes+=f.length();files.add(f);if(f.getName().endsWith(".kt"))r.kotlin++;if(f.getName().endsWith(".java"))r.java++;if(f.getName().endsWith(".xml"))r.xml++;} }
    }
    public static Document xml(String text) throws Exception {
        String lower=text.toLowerCase(Locale.ROOT); if(lower.contains("<!doctype")||lower.contains("<!entity")) throw new IOException("DTD and entities are disabled");
        DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();f.setNamespaceAware(true);f.setExpandEntityReferences(false);
        try{f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);}catch(ParserConfigurationException ignored){}
        try{f.setFeature("http://xml.org/sax/features/external-general-entities",false);f.setFeature("http://xml.org/sax/features/external-parameter-entities",false);}catch(ParserConfigurationException ignored){}
        DocumentBuilder builder=f.newDocumentBuilder();builder.setEntityResolver((p,s)->{throw new SAXException("External entities disabled");});
        builder.setErrorHandler(new ErrorHandler(){public void warning(SAXParseException e)throws SAXException{throw e;}public void error(SAXParseException e)throws SAXException{throw e;}public void fatalError(SAXParseException e)throws SAXException{throw e;}});
        return builder.parse(new InputSource(new StringReader(text)));
    }
    public void parseManifest(String text,String path,Report r) throws Exception {
        Document doc=xml(text); Element root=doc.getDocumentElement();if(!root.getTagName().equals("manifest")) throw new IOException("Root element must be manifest");
        putIf(r,"Package",root.getAttribute("package")); putIf(r,"Version name",attr(root,"versionName"));putIf(r,"Version code",attr(root,"versionCode"));
        NodeList uses=doc.getElementsByTagName("uses-sdk"); if(uses.getLength()>0){putIf(r,"Min SDK",attr((Element)uses.item(0),"minSdkVersion"));putIf(r,"Target SDK",attr((Element)uses.item(0),"targetSdkVersion"));}
        NodeList apps=doc.getElementsByTagName("application");
        if(apps.getLength()>0) {Element app=(Element)apps.item(0);putIf(r,"App name",attr(app,"label"));putIf(r,"Theme",attr(app,"theme")); if("true".equals(attr(app,"usesCleartextTraffic"))) r.problems.add(new Problem("Warning",path,lineOf(text,"usesCleartextTraffic"),"Cleartext network traffic enabled","Unencrypted HTTP can expose data in transit.","Review HTTP requirements; consider android:usesCleartextTraffic=\"false\"."));}
        readNames(doc,"uses-permission",r.permissions); readNames(doc,"activity",r.activities);readNames(doc,"activity-alias",r.activities);readNames(doc,"service",r.services);readNames(doc,"receiver",r.receivers);readNames(doc,"provider",r.providers);
        for(String tag:Arrays.asList("activity","service","receiver")) {NodeList nodes=doc.getElementsByTagName(tag);for(int i=0;i<nodes.getLength();i++){Element e=(Element)nodes.item(i);if(e.getElementsByTagName("intent-filter").getLength()>0&&attr(e,"exported").isEmpty())r.problems.add(new Problem("Warning",path,lineOf(text,attr(e,"name")),"Explicit exported attribute missing",tag+" "+attr(e,"name")+" has an intent filter. Android 12+ requires an explicit exported value when targeting API 31+.","Set android:exported explicitly after reviewing whether this component should be public."));}}
    }
    private static String attr(Element e,String name){return e.getAttributeNS("http://schemas.android.com/apk/res/android",name);}
    private static void readNames(Document d,String tag,List<String> out){NodeList list=d.getElementsByTagName(tag);for(int i=0;i<list.getLength();i++)out.add(attr((Element)list.item(i),"name"));}
    private static void putIf(Report r,String k,String v){if(v!=null&&!v.isEmpty()&&!r.fields.containsKey(k))r.fields.put(k,v);}
    public void parseGradle(String text,String path,Report r) {
        if((text.contains("com.android.application")||text.contains("com.android.library"))&&!text.contains("apply false")){r.modules++;if(r.gradle.isEmpty())r.gradle=path;}
        for(String[] pair:new String[][]{{"Package","applicationId"},{"Namespace","namespace"},{"Version name","versionName"}}) putMatch(r,pair[0],text,"\\b"+pair[1]+"\\s*(?:=\\s*)?[\\\"']([^\\\"']+)[\\\"']");
        for(String[] pair:new String[][]{{"Min SDK","minSdk(?:Version)?"},{"Target SDK","targetSdk(?:Version)?"},{"Compile SDK","compileSdk(?:Version)?"},{"Version code","versionCode"}}) putMatch(r,pair[0],text,"\\b"+pair[1]+"\\s*(?:=\\s*)?(\\d+)");
        putMatch(r,"Android Gradle Plugin",text,"com.android.tools.build:gradle:([0-9.]+)");
        putMatch(r,"Android Gradle Plugin",text,"id\\s*\\(?[\"']com.android.application[\"']\\)?\\s+version\\s*[\"']([^\"']+)");
        Matcher deps=Pattern.compile("\\b(implementation|api|compileOnly|runtimeOnly|testImplementation|androidTestImplementation|debugImplementation)\\s*\\(?\\s*[\"']([^\"']+)[\"']").matcher(text);
        while(deps.find()) r.dependencies.add(new Dependency(deps.group(1),deps.group(2),path,lineOfIndex(text,deps.start())));
        r.compose|=text.matches("(?s).*compose\\s*=\\s*true.*");
    }
    private static void putMatch(Report r,String key,String text,String regex){Matcher m=Pattern.compile(regex).matcher(text);if(m.find())putIf(r,key,m.group(1));}
    public static int lineOf(String text,String token){int pos=text.indexOf(token);return pos<0?1:lineOfIndex(text,pos);}
    private static int lineOfIndex(String text,int pos){int n=1;for(int i=0;i<pos;i++)if(text.charAt(i)=='\n')n++;return n;}
    private static int line(Exception e){return e instanceof SAXParseException?Math.max(1,((SAXParseException)e).getLineNumber()):1;}
    private static int number(String s){try{return Integer.parseInt(s);}catch(Exception e){return 0;}}
    public static String humanBytes(long bytes){if(bytes<1024)return bytes+" B";if(bytes<1048576)return String.format(Locale.ROOT,"%.1f KB",bytes/1024.0);return String.format(Locale.ROOT,"%.1f MB",bytes/1048576.0);}
}
