from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
mit='''MIT License

Copyright (c) 2026 Android Forge contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
'''
(root/'LICENSE').write_text(mit)
notices=['ANDROID FORGE — OPEN SOURCE NOTICES\n',mit]
modules=root/'editor/node_modules'
for file in sorted(modules.glob('**/package.json')):
 if 'node_modules' not in file.parts: continue
 try: info=json.loads(file.read_text())
 except Exception: continue
 name=info.get('name','')
 if not (name.startswith('@codemirror/') or name.startswith('@lezer/') or name in ['codemirror','style-mod','w3c-keyname','crelt','@marijn/find-cluster-break']):continue
 notices.append('\n'+'='*70+'\n'+name+' '+info.get('version','')+'\n')
 for candidate in ['LICENSE','LICENSE.md','LICENSE.txt']:
  path=file.parent/candidate
  if path.exists(): notices.append(path.read_text());break
 else:notices.append('License: '+str(info.get('license','See upstream repository')))
notices.append('''\nRE2/J 1.8 — BSD 3-Clause License\nhttps://github.com/google/re2j\n
Copyright (c) 2009 The Go Authors. All rights reserved.
Copyright (c) 2010 The RE2 Authors. All rights reserved.
Copyright (c) 2014 The RE2/J Authors. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
* Neither the name of Google Inc. nor the names of its contributors may
be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
''')
text='\n'.join(notices)
(root/'app/src/main/assets/OPEN_SOURCE_LICENSES.txt').write_text(text)
(root/'THIRD_PARTY_NOTICES.txt').write_text(text)
print('Bundled notices:',len(text),'characters')
