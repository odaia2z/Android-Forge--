package dev.androidforge.core;

import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.util.*;

/** All project access must go through this boundary. No script execution. */
public final class SafeFiles {
    public static final long MAX_TEXT = 2L * 1024 * 1024;
    public static final long MAX_FILE = 64L * 1024 * 1024;
    public static final long MAX_PROJECT = 256L * 1024 * 1024;
    public static final int MAX_ENTRIES = 20000;
    private SafeFiles() {}

    public static String validate(String path) throws IOException {
        if (path == null || path.isEmpty() || path.length() > 1024 || path.startsWith("/") || path.contains("\\") || path.contains(":"))
            throw new IOException("Unsafe relative path");
        for (char ch : path.toCharArray()) if (ch < 32) throw new IOException("Control character in path");
        String trimmed = path.endsWith("/") ? path.substring(0, path.length()-1) : path;
        for (String part : trimmed.split("/", -1)) {
            if (part.isEmpty() || part.equals(".") || part.equals("..")) throw new IOException("Path traversal or empty component rejected");
        }
        return trimmed;
    }

    public static File resolve(File root, String path) throws IOException {
        String safe = validate(path);
        File current = root;
        if (Files.isSymbolicLink(root.toPath())) throw new IOException("Symbolic link root rejected");
        for (String component : safe.split("/")) {
            current = new File(current, component);
            if (Files.isSymbolicLink(current.toPath())) throw new IOException("Symbolic links are not supported");
        }
        String base = root.getCanonicalPath() + File.separator;
        if (!current.getCanonicalPath().startsWith(base)) throw new IOException("Path escapes project sandbox");
        return current;
    }

    public static byte[] read(File file, long maximum) throws IOException {
        if (file.length() > maximum) throw new IOException("File exceeds limit: " + maximum + " bytes");
        try (InputStream in = new FileInputStream(file); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            copy(in, out, maximum); return out.toByteArray();
        }
    }

    public static String text(File file) throws IOException {
        byte[] bytes = read(file, MAX_TEXT);
        try {
            String value = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(java.nio.ByteBuffer.wrap(bytes)).toString();
            if (value.indexOf('\0') >= 0) throw new IOException("Binary file: text editing disabled");
            return value;
        } catch (CharacterCodingException e) { throw new IOException("Not UTF-8 text: export or open externally", e); }
    }

    public static void atomicWrite(File target, byte[] bytes) throws IOException {
        if (bytes.length > MAX_FILE) throw new IOException("File too large");
        File parent = target.getParentFile();
        if (!parent.exists() && !parent.mkdirs()) throw new IOException("Cannot create directory");
        File temporary = File.createTempFile(".forge-write-", ".tmp", parent);
        try {
            try (FileOutputStream out = new FileOutputStream(temporary)) { out.write(bytes); out.getFD().sync(); }
            try { Files.move(temporary.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temporary.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING); }
        } finally { temporary.delete(); }
    }

    public static long copy(InputStream in, OutputStream out, long limit) throws IOException {
        byte[] buffer = new byte[32768]; long count=0; int n;
        while ((n=in.read(buffer))!=-1) { count+=n; if(count>limit) throw new IOException("Safety size limit exceeded"); out.write(buffer,0,n); }
        return count;
    }

    public static void deleteTree(File file) throws IOException {
        if (Files.isSymbolicLink(file.toPath())) { Files.delete(file.toPath()); return; }
        File[] children=file.listFiles();
        if(children!=null) for(File child:children) deleteTree(child);
        if(file.exists() && !file.delete()) throw new IOException("Cannot delete " + file.getName());
    }

    public static List<File> children(File directory) {
        File[] files=directory.listFiles(); if(files==null) return new ArrayList<>();
        List<File> result=new ArrayList<>(Arrays.asList(files));
        result.sort(Comparator.comparing((File f)->!f.isDirectory()).thenComparing(f->f.getName().toLowerCase(Locale.ROOT)));
        return result;
    }

    public static String relative(File root, File file) { return root.toPath().relativize(file.toPath()).toString().replace(File.separatorChar,'/'); }
    public static boolean isText(String name) { return name.matches("(?i).*(\\.(kt|kts|java|xml|gradle|json|js|jsx|ts|tsx|html|css|md|txt|properties|toml|yaml|yml|sh|svg|pro|gitignore)|gradlew|LICENSE|README)$"); }
}
