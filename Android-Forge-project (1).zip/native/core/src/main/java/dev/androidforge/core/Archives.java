package dev.androidforge.core;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

public final class Archives {
    private Archives() {}
    public static void extract(File archive, File destination) throws IOException {
        if(destination.exists()) throw new IOException("Extraction destination must be new");
        rejectLinks(archive);
        if(!destination.mkdirs()) throw new IOException("Cannot create extraction sandbox");
        Set<String> seen=new HashSet<>(); long total=0; int count=0;
        try (ZipFile zip=new ZipFile(archive)) {
            if(zip.size()==0) throw new IOException("Empty ZIP archive");
            Enumeration<? extends ZipEntry> entries=zip.entries();
            while(entries.hasMoreElements()) {
                ZipEntry entry=entries.nextElement();
                String path=SafeFiles.validate(entry.getName());
                if(!seen.add(path)) throw new IOException("Duplicate ZIP entry: "+path);
                if(++count>SafeFiles.MAX_ENTRIES) throw new IOException("Too many ZIP entries");
                if(entry.getSize()>SafeFiles.MAX_FILE || (entry.getCompressedSize()>0 && entry.getSize()/entry.getCompressedSize()>1000)) throw new IOException("ZIP decompression safety limit");
                File target=SafeFiles.resolve(destination,path);
                if(entry.isDirectory()) { if(!target.isDirectory()&&!target.mkdirs()) throw new IOException("Directory conflict"); continue; }
                File parent=target.getParentFile();
                if(!parent.exists()&&!parent.mkdirs()) throw new IOException("ZIP path conflict");
                CRC32 crc=new CRC32(); long written;
                try(InputStream input=zip.getInputStream(entry); CheckedInputStream in=new CheckedInputStream(input,crc); OutputStream out=new FileOutputStream(target)) {
                    written=SafeFiles.copy(in,out,Math.min(SafeFiles.MAX_FILE,SafeFiles.MAX_PROJECT-total));
                }
                total+=written;
                if(entry.getSize()!=written || (entry.getCrc()!=-1 && entry.getCrc()!=crc.getValue())) throw new IOException("ZIP integrity check failed");
                if(entry.getTime()>0) target.setLastModified(entry.getTime());
            }
        } catch(Exception e) { SafeFiles.deleteTree(destination); throw e instanceof IOException?(IOException)e:new IOException(e); }
    }

    /** ZIP central-directory Unix mode check. Extraction never materializes symlinks. */
    static void rejectLinks(File archive) throws IOException {
        try(RandomAccessFile f=new RandomAccessFile(archive,"r")) {
            long length=f.length(); if(length<22) throw new IOException("Invalid ZIP");
            long end=-1;
            for(long pos=length-22;pos>=Math.max(0,length-65557);pos--) {
                f.seek(pos); if(Integer.reverseBytes(f.readInt())==0x06054b50) { f.seek(pos+20); int comment=Short.toUnsignedInt(Short.reverseBytes(f.readShort())); if(pos+22+comment==length){end=pos;break;} }
            }
            if(end<0) throw new IOException("Missing ZIP directory");
            f.seek(end+10); int count=Short.toUnsignedInt(Short.reverseBytes(f.readShort()));
            f.seek(end+16); long offset=Integer.toUnsignedLong(Integer.reverseBytes(f.readInt()));
            if(count==65535 || offset==0xffffffffL) throw new IOException("ZIP64 archives are not supported in this release");
            if(count>SafeFiles.MAX_ENTRIES) throw new IOException("Too many ZIP entries");
            for(int i=0;i<count;i++) {
                if(offset+46>length) throw new IOException("Invalid ZIP directory bounds");
                f.seek(offset); if(Integer.reverseBytes(f.readInt())!=0x02014b50) throw new IOException("Invalid ZIP directory entry");
                f.seek(offset+8); int flags=Short.toUnsignedInt(Short.reverseBytes(f.readShort()));
                if((flags&1)!=0) throw new IOException("Encrypted archives are not supported");
                f.seek(offset+28); int name=Short.toUnsignedInt(Short.reverseBytes(f.readShort())); int extra=Short.toUnsignedInt(Short.reverseBytes(f.readShort())); int comment=Short.toUnsignedInt(Short.reverseBytes(f.readShort()));
                f.seek(offset+38); long attrs=Integer.toUnsignedLong(Integer.reverseBytes(f.readInt()));
                if((((attrs>>>16)&0170000)==0120000)) throw new IOException("Symbolic link ZIP entry rejected");
                offset+=46L+name+extra+comment;
            }
        }
    }

    public static void export(File root, OutputStream output, boolean sourceOnly) throws IOException {
        try(ZipOutputStream zip=new ZipOutputStream(new BufferedOutputStream(output))) {
            int[] count={0}; long[] size={0}; add(root,root,zip,sourceOnly,count,size);
        }
    }
    private static void add(File root, File dir, ZipOutputStream zip, boolean sourceOnly, int[] count, long[] size) throws IOException {
        for(File file:SafeFiles.children(dir)) {
            String relative=SafeFiles.relative(root,file); SafeFiles.resolve(root,relative);
            if(++count[0]>SafeFiles.MAX_ENTRIES) throw new IOException("Too many export entries");
            if(sourceOnly&&(file.getName().equals(".git")||file.getName().equals("build")||file.getName().equals(".gradle")||file.getName().equals("node_modules"))) continue;
            if(sourceOnly&&!file.isDirectory()&&!relative.contains("src/")&&!SafeFiles.isText(file.getName())&&!relative.contains("res/")) continue;
            ZipEntry entry=new ZipEntry(relative+(file.isDirectory()?"/":"")); entry.setTime(file.lastModified()); zip.putNextEntry(entry);
            if(file.isFile()) try(InputStream in=new FileInputStream(file)) { size[0]+=SafeFiles.copy(in,zip,Math.min(SafeFiles.MAX_FILE,SafeFiles.MAX_PROJECT-size[0])); }
            zip.closeEntry();
            if(file.isDirectory()) add(root,file,zip,sourceOnly,count,size);
        }
    }

    public static class Inventory {
        public int entries, dexFiles, resources; public long uncompressed;
        public final Set<String> modules=new TreeSet<>(), abis=new TreeSet<>();
        public final List<String> manifests=new ArrayList<>(), signatures=new ArrayList<>();
        public long dexClasses,dexMethods;
    }
    public static Inventory inspect(File archive) throws IOException {
        rejectLinks(archive); Inventory result=new Inventory();
        try(ZipFile zip=new ZipFile(archive)) {
            Enumeration<? extends ZipEntry> all=zip.entries();
            while(all.hasMoreElements()) {
                ZipEntry e=all.nextElement(); String path=SafeFiles.validate(e.getName());
                if(++result.entries>SafeFiles.MAX_ENTRIES) throw new IOException("Archive entry limit");
                result.uncompressed+=Math.max(0,e.getSize());
                if(path.endsWith("AndroidManifest.xml")) { result.manifests.add(path); if(path.contains("/")) result.modules.add(path.split("/")[0]); }
                if(path.startsWith("res/")||path.contains("/res/")) result.resources++;
                if(path.startsWith("META-INF/")) result.signatures.add(path);
                String[] parts=path.split("/"); for(int i=0;i<parts.length-1;i++) if(parts[i].equals("lib")) result.abis.add(parts[i+1]);
                if(path.endsWith(".dex")) {
                    result.dexFiles++;
                    try(InputStream in=zip.getInputStream(e)) {
                        byte[] header=new byte[112]; int n=0,r; while(n<112&&(r=in.read(header,n,112-n))>0)n+=r;
                        if(n==112&&header[0]=='d'&&header[1]=='e'&&header[2]=='x'&&header[3]=='\n') { result.dexMethods+=u32(header,88); result.dexClasses+=u32(header,96); }
                    }
                }
            }
        }
        return result;
    }
    private static long u32(byte[] b,int o) { return (b[o]&255L)|((b[o+1]&255L)<<8)|((b[o+2]&255L)<<16)|((b[o+3]&255L)<<24); }
}
