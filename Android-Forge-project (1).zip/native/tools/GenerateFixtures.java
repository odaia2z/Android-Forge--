import dev.androidforge.core.Templates;
import java.io.File;
public final class GenerateFixtures {
    public static void main(String[] args)throws Exception{
        File base=new File(args[0]);
        Templates.create(new File(base,"android-java"),"Forge Sample","dev.forge.sample","Java","XML",29,35);
        Templates.create(new File(base,"mobile-web"),"Pocket Studio","dev.forge.web","Kotlin","Web",29,35);
        System.out.println("Created real Android Java and Mobile Web test projects at "+base);
    }
}
