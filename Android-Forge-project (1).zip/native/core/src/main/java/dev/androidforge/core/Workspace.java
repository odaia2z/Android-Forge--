package dev.androidforge.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import com.google.re2j.*;

public final class Workspace {
    public final File base, projects, backups, drafts, revisions;
    public Workspace(File base) throws IOException {
        this.base=base; projects=new File(base,"projects"); backups=new File(base,"backups"); drafts=new File(base,"drafts"); revisions=new File(base,"revisions");
        for(File dir:Arrays.asList(projects,backups,drafts,revisions)) if(!dir.exists()&&!dir.mkdirs()) throw new IOException("Storage unavailable");
    }
    public File project(String id) throws IOException { if(id==null||!id.matches("[a-f0-9-]{36}")) throw new IOException("Invalid project ID"); return SafeFiles.resolve(projects,id); }
    public String create() throws IOException { String id=UUID.randomUUID().toString(); if(!project(id).mkdir()) throw new IOException("Cannot create project"); return id; }
    public String importZip(File archive) throws IOException {
        String id=UUID.randomUUID().toString(); Archives.extract(archive,project(id)); return id;
    }
    public File file(String id,String path) throws IOException { return SafeFiles.resolve(project(id),path); }
    public String read(String id,String path) throws IOException { return SafeFiles.text(file(id,path)); }
    public File draft(String id,String path) throws IOException { return SafeFiles.resolve(SafeFiles.resolve(drafts,id),path); }
    public File revision(String id,String path) throws IOException { return SafeFiles.resolve(SafeFiles.resolve(revisions,id),path); }
    public synchronized void saveDraft(String id,String path,String value) throws IOException { SafeFiles.atomicWrite(draft(id,path),value.getBytes(StandardCharsets.UTF_8)); }
    public synchronized void discardDraft(String id,String path) throws IOException { Files.deleteIfExists(draft(id,path).toPath()); }
    public synchronized void save(String id,String path,String value) throws IOException {
        byte[] bytes=value.getBytes(StandardCharsets.UTF_8); if(bytes.length>SafeFiles.MAX_TEXT) throw new IOException("Editor file limit is 2 MiB");
        File target=file(id,path);
        if(target.exists()) SafeFiles.atomicWrite(revision(id,path),SafeFiles.read(target,SafeFiles.MAX_TEXT));
        SafeFiles.atomicWrite(target,bytes); discardDraft(id,path);
    }
    public synchronized void createFile(String id,String path,String value) throws IOException {
        File target=file(id,path); if(target.exists()) throw new IOException("File already exists");
        SafeFiles.atomicWrite(target,value.getBytes(StandardCharsets.UTF_8));
    }
    public synchronized void mkdir(String id,String path) throws IOException { File target=file(id,path); if(target.exists()||!target.mkdirs()) throw new IOException("Directory already exists or cannot be created"); }
    public synchronized void move(String id,String from,String to,boolean copy) throws IOException {
        File src=file(id,from), dst=file(id,to); if(!src.exists()||dst.exists()) throw new IOException("Source missing or destination exists");
        if(dst.getCanonicalPath().startsWith(src.getCanonicalPath()+"/")) throw new IOException("Cannot move a directory inside itself");
        if(!dst.getParentFile().exists()&&!dst.getParentFile().mkdirs()) throw new IOException("Cannot create parent");
        if(copy) copyTree(src,dst); else Files.move(src.toPath(),dst.toPath());
    }
    private void copyTree(File from,File to) throws IOException {
        if(Files.isSymbolicLink(from.toPath())) throw new IOException("Symlink rejected");
        if(from.isDirectory()) { if(!to.mkdir()) throw new IOException("Cannot create directory"); for(File child:SafeFiles.children(from)) copyTree(child,new File(to,child.getName())); }
        else try(InputStream in=new FileInputStream(from); OutputStream out=new FileOutputStream(to)) { SafeFiles.copy(in,out,SafeFiles.MAX_FILE); }
    }
    public synchronized void deleteFile(String id,String path) throws IOException { backup(id); SafeFiles.deleteTree(file(id,path)); SafeFiles.deleteTree(draft(id,path)); }
    public synchronized File backup(String id) throws IOException {
        File file=new File(backups,id+"-"+System.currentTimeMillis()+"-"+UUID.randomUUID().toString().substring(0,8)+".zip"); File temporary=new File(file+".tmp");
        try { Archives.export(project(id),new FileOutputStream(temporary),false); Files.move(temporary.toPath(),file.toPath()); return file; }
        finally { temporary.delete(); }
    }
    public synchronized void deleteProject(String id) throws IOException { backup(id); SafeFiles.deleteTree(project(id)); SafeFiles.deleteTree(new File(drafts,id)); SafeFiles.deleteTree(new File(revisions,id)); }
    public List<File> backups() { List<File> list=SafeFiles.children(backups); list.removeIf(f->!f.getName().endsWith(".zip")); list.sort((a,b)->Long.compare(b.lastModified(),a.lastModified())); return list; }
    public void export(String id,OutputStream output,boolean sourceOnly) throws IOException { Archives.export(project(id),output,sourceOnly); }

    public static final class Hit {
        public final String path,preview; public final int line,column;
        public Hit(String p,int l,int c,String v) { path=p;line=l;column=c;preview=v; }
    }
    public List<Hit> search(String id,String term,boolean sensitive,boolean regex,boolean whole,String extension,String folder) throws IOException {
        if(term.isEmpty()||term.length()>200) throw new IOException("Search must contain 1–200 characters");
        // Deliberately bounded regex subset: groups, alternation and backreferences may cause exponential work.
        if(regex&&(term.matches(".*[()|{}].*")||term.matches(".*\\\\[1-9].*")||term.matches(".*[+*?][+*?].*"))) throw new IOException("For safety, regex groups, alternation, backreferences and nested quantifiers are disabled");
        String pattern=regex?term:Pattern.quote(term); if(whole) pattern="\\b(?:"+pattern+")\\b";
        Pattern compiled;
        try { compiled=Pattern.compile(pattern,sensitive?0:Pattern.CASE_INSENSITIVE); }
        catch(PatternSyntaxException e) { throw new IOException("Invalid regular expression"); }
        File root=project(id), start=folder.isEmpty()?root:SafeFiles.resolve(root,folder);
        List<Hit> hits=new ArrayList<>(); searchDir(root,start,compiled,extension,hits,new int[]{0}); return hits;
    }
    private void searchDir(File root,File dir,Pattern pattern,String extension,List<Hit> hits,int[] visited) throws IOException {
        for(File file:SafeFiles.children(dir)) {
            if(++visited[0]>SafeFiles.MAX_ENTRIES||hits.size()>=200) return;
            SafeFiles.resolve(root,SafeFiles.relative(root,file));
            if(file.isDirectory()) { if(!Arrays.asList(".git","node_modules","build",".gradle").contains(file.getName())) searchDir(root,file,pattern,extension,hits,visited); continue; }
            if(!SafeFiles.isText(file.getName())||file.length()>SafeFiles.MAX_TEXT||(!extension.isEmpty()&&!file.getName().endsWith(extension))) continue;
            try(BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream(file),StandardCharsets.UTF_8))) {
                String line; int number=0;
                while((line=reader.readLine())!=null) { number++; if(line.length()>16384) continue;
                    Matcher match=pattern.matcher(line); if(match.find()) { hits.add(new Hit(SafeFiles.relative(root,file),number,match.start()+1,line.trim())); if(hits.size()>=200) return; }
                }
            }
        }
    }
}
