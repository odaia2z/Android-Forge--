# Android Forge architecture

## Native application, not a hosted IDE

Android Forge is a native Android application written in Java 17, using platform Android views and an embedded, locally bundled CodeMirror editor. Java was selected to keep the core portable and independently testable without Android. The application targets Android 10 (API 29) and above. The source repository has an `app` Android module and a `core` Java library. No user account, remote database, API key, paid inference, or cloud execution is part of the core architecture.

## Module boundaries and data flow

The UI sends operations to a single background executor. The platform layer adapts Android Storage Access Framework document streams to the core engine. The core validates all relative paths before reading or writing project files. Results return to the main thread and are rendered from actual filesystem data. An import is staged in a temporary directory, validated, and committed only on success. A failed import removes its staging area.

`core` owns safe paths, ZIP import/export, project templates, bounded text access, file operations, revision history, drafts, backups, source inspection, archive inspection and search. `app/platform` owns the metadata database, document picker, Android package inspection, capability detection and WebView policy. `app/ui` owns navigation, native components, file screens, editor sessions and report rendering. CodeMirror assets live in `app/src/main/assets/editor`; their editable source lives in `editor`.

## Storage model

Projects live in the private application files directory under `projects/<uuid>/`. Project code is never stored in the metadata database. SQLite stores the project identifier, display name, timestamps and project kind. Backups, drafts and revisions live beside, not inside, project directories, so a full ZIP export does not inject IDE-specific files into the user's source. Updates retain private storage. Uninstalling the application or clearing application data removes it; users must export backups to a chosen document provider to survive uninstall.

Files are loaded on demand. Text editing is limited to 2 MiB per file. ZIP import is streamed, capped at 256 MiB uncompressed, 64 MiB per file and 20,000 entries. These are transparent resource-safety limits, not usage quotas. Binary files are copied byte-for-byte. Empty directories are retained in full export. ZIP filesystem permissions and symlink semantics are not preserved: symbolic links are rejected where detected, and no imported script is automatically executed.

## Security model

Every imported project is untrusted. Paths must be relative, normalized, free of parent traversal, NUL characters, drive prefixes and symbolic-link escapes. ZIP extraction rejects duplicates and file/directory conflicts. Writes use a temporary sibling plus atomic replacement where supported. Editor changes produce a previous revision, and unsaved documents have recovery drafts. Deletion, restore and JavaScript preview require an explicit in-app decision.

The editor WebView can load only packaged editor assets. It exposes a narrow text-only bridge, never a general file or command bridge, and imported text is passed as JSON data rather than interpolated executable code. Imported HTML is never loaded in this WebView.

The preview WebView is a separate Activity without a JavaScript bridge. Only files within the selected project can be served through a reserved HTTPS origin. Filesystem and content URI access, popups, external navigation and network requests are denied. The APK requests no Internet or broad storage permission. JavaScript is off until the user consents for a preview session. This is a WebView preview, not an Android emulator. Source React Native/Expo projects require their build toolchain; only static HTML/CSS/JS or an already exported web build can be previewed directly.

## Analysis model

Source inspection parses XML securely and extracts literal Gradle values without evaluating Gradle. Version catalogs and arbitrary build logic are not resolved. Findings carry file paths and line numbers when known. Results are explicitly static, incomplete evidence rather than Kotlin/Java compiler results. A health score is not fabricated. APK inspection combines bounded ZIP/DEX inventory with Android's PackageManager archive parser. AAB inspection provides archive structure and module/ABI inventory; binary protobuf manifest decoding is not claimed.

## Build and extension model

`BuildEngine` is an interface with explicit capabilities and a result model. The initial on-device provider is unavailable: the app does not bundle a JDK, Android SDK, Gradle execution sandbox or emulator. A build action first validates the real project and explains the missing runtime. It never emits fabricated compilation logs or APKs. Full export provides the alternative path to Android Studio or an independently provisioned build worker. Future providers must obtain user approval, isolate untrusted build scripts, preserve logs and validate artifact paths before offering downloads.

A native debug APK of Android Forge itself is built in the development environment. This must not be confused with building arbitrary imported projects inside Android Forge.

## Error and recovery model

I/O, parsing and validation errors propagate as user-readable operation failures. A failed save retains the draft and existing file. Drafts are restored only after user confirmation. A save stores the prior file outside the source tree. Restoring a ZIP always creates a new project rather than overwriting another. A cancelled document export leaves the original project untouched. Long operations run off the main thread and show progress state; this release uses indeterminate progress and bounded operations rather than a persistent background service.

## References

CodeMirror is distributed under the MIT license and provides a modular editor with mobile support, history and search [1]. Android documents its SDK package manager separately from application runtime APIs [2].

[1]: https://codemirror.net/ "CodeMirror editor features and license"
[2]: https://developer.android.com/tools/sdkmanager "Android SDK package manager"
