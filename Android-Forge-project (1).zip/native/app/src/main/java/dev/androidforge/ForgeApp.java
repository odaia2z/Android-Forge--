package dev.androidforge;

import android.app.Application;
import android.content.SharedPreferences;
import dev.androidforge.core.*;
import dev.androidforge.platform.ProjectDatabase;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public final class ForgeApp extends Application {
    public Workspace workspace; public ProjectDatabase database;
    public final ExecutorService io=Executors.newSingleThreadExecutor();
    public SharedPreferences settings;
    public void onCreate(){super.onCreate();settings=getSharedPreferences("forge-settings",MODE_PRIVATE);try{workspace=new Workspace(getFilesDir());}catch(IOException e){throw new IllegalStateException(e);}database=new ProjectDatabase(this);
        Thread.UncaughtExceptionHandler previous=Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread,error)->{log("CRASH "+error.getClass().getSimpleName()+": "+error.getMessage());if(previous!=null)previous.uncaughtException(thread,error);});
    }
    public synchronized void log(String event){try{File file=new File(getFilesDir(),"application.log");if(file.length()>1024*1024)SafeFiles.atomicWrite(file,new byte[0]);try(FileOutputStream out=new FileOutputStream(file,true)){out.write((new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.ROOT).format(new Date())+"  "+event+"\n").getBytes(StandardCharsets.UTF_8));}}catch(IOException ignored){}}
    public synchronized String logs(){try{return SafeFiles.text(new File(getFilesDir(),"application.log"));}catch(IOException e){return "";}}
    public synchronized void clearLogs(){new File(getFilesDir(),"application.log").delete();}
    public void addProject(String id,String name,String kind)throws Exception{database.add(id,name,kind);try{Analyzer.Report r=new Analyzer().analyze(workspace.project(id));database.index(id,r.files,r.bytes,r.fields.getOrDefault("UI",kind));}catch(Exception e){log("INDEX warning "+e.getMessage());}log("PROJECT added "+name);}
    public void addWrapper(String id)throws IOException{for(String path:new String[]{"gradlew","gradlew.bat","gradle/wrapper/gradle-wrapper.jar","gradle/wrapper/gradle-wrapper.properties"}){try(InputStream in=getAssets().open("template/"+path)){File target=workspace.file(id,path);target.getParentFile().mkdirs();try(OutputStream out=new FileOutputStream(target)){SafeFiles.copy(in,out,SafeFiles.MAX_FILE);}}}workspace.file(id,"gradlew").setExecutable(true,false);}
}
