package dev.androidforge.platform;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import dev.androidforge.core.*;
import java.io.*;
import java.util.*;

public final class DocumentIo {
    public static void importTree(ContentResolver resolver,Uri tree,File destination)throws IOException{
        String id=DocumentsContract.getTreeDocumentId(tree);copyChildren(resolver,tree,id,destination,destination,new long[]{0,0},0);
    }
    private static void copyChildren(ContentResolver r,Uri tree,String id,File root,File into,long[] limits,int depth)throws IOException{
        if(depth>64)throw new IOException("Directory nesting limit");
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,id);
        try(Cursor cursor=r.query(children,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE},null,null,null)){
            if(cursor==null)throw new IOException("Folder provider unavailable");
            while(cursor.moveToNext()){
                if(++limits[0]>SafeFiles.MAX_ENTRIES)throw new IOException("Too many files");
                String name=cursor.getString(1);SafeFiles.validate(name);if(name.contains("/"))throw new IOException("Invalid provider filename");
                File target=SafeFiles.resolve(root,SafeFiles.relative(root,new File(into,name)));if(target.exists())throw new IOException("Duplicate provider filename");
                String child=cursor.getString(0);
                if(DocumentsContract.Document.MIME_TYPE_DIR.equals(cursor.getString(2))){if(!target.mkdir())throw new IOException("Cannot create directory");copyChildren(r,tree,child,root,target,limits,depth+1);}
                else try(InputStream in=r.openInputStream(DocumentsContract.buildDocumentUriUsingTree(tree,child));OutputStream out=new FileOutputStream(target)){if(in==null)throw new IOException("Cannot read provider file");limits[1]+=SafeFiles.copy(in,out,Math.min(SafeFiles.MAX_FILE,SafeFiles.MAX_PROJECT-limits[1]));}
            }
        }
    }
}
