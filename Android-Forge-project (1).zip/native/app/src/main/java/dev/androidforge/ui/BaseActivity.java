package dev.androidforge.ui;

import android.app.*;
import android.content.*;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import dev.androidforge.*;
import dev.androidforge.core.*;
import java.io.*;
import java.util.*;

public abstract class BaseActivity extends Activity {
    protected ForgeApp forge; protected LinearLayout root,body; protected boolean dark;
    protected int bg,surface,fg,muted,border,accent=Color.rgb(101,220,172); protected ProgressDialog progress;
    protected interface Work<T>{T run()throws Exception;} protected interface Done<T>{void accept(T result)throws Exception;}
    protected interface Exporter{void write(OutputStream out)throws Exception;}
    private Exporter exporter; private Done<Uri> picker;
    @Override protected void attachBaseContext(Context base){Configuration config=new Configuration(base.getResources().getConfiguration());String language=base.getSharedPreferences("forge-settings",MODE_PRIVATE).getString("language","ar");config.setLocale(new Locale(language));super.attachBaseContext(base.createConfigurationContext(config));}
    @Override public void onCreate(Bundle state){super.onCreate(state);forge=(ForgeApp)getApplication();dark=forge.settings.getBoolean("dark",true);bg=Color.parseColor(dark?"#0C1220":"#F4F6F8");surface=Color.parseColor(dark?"#151E2D":"#FFFFFF");fg=Color.parseColor(dark?"#ECF1F6":"#152335");muted=Color.parseColor(dark?"#92A1B5":"#607084");border=Color.parseColor(dark?"#263145":"#E0E6EC");if(!dark)accent=Color.parseColor("#187B59");getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);}
    protected void page(String title,boolean back){root=column();root.setBackgroundColor(bg);root.setFitsSystemWindows(true);root.setPadding(dp(20),dp(10),dp(20),dp(10));setContentView(root);
        root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(dp(20),insets.getSystemWindowInsetTop()+dp(10),dp(20),insets.getSystemWindowInsetBottom()+dp(10));return insets.consumeSystemWindowInsets();});
        LinearLayout header=row();header.setGravity(Gravity.CENTER_VERTICAL);TextView logo=text(back?"‹":"F",back?34:25,accent,true);logo.setGravity(Gravity.CENTER);logo.setContentDescription(back?getString(R.string.close):"Android Forge");header.addView(logo,new LinearLayout.LayoutParams(dp(40),dp(44)));if(back)logo.setOnClickListener(v->onBackPressed());TextView heading=text(title,20,fg,true);header.addView(heading,new LinearLayout.LayoutParams(0,dp(48),1));heading.setGravity(Gravity.CENTER_VERTICAL);TextView label=text("LOCAL",9,accent,true);label.setLetterSpacing(.12f);header.addView(label);root.addView(header);body=column();root.addView(body,new LinearLayout.LayoutParams(-1,0,1));}
    protected LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    protected LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
    protected int dp(float value){return Math.round(value*getResources().getDisplayMetrics().density);}
    protected TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("kern");t.setIncludeFontPadding(false);t.setLineSpacing(dp(3),1);if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;}
    protected TextView text(int resource,int size,int color,boolean bold){return text(getString(resource),size,color,bold);}
    protected GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    protected void gap(LinearLayout parent,int height){View spacer=new View(this);parent.addView(spacer,new LinearLayout.LayoutParams(1,dp(height)));}
    protected TextView button(String title,boolean primary,Runnable action){TextView b=text(title,14,primary?(dark?bg:Color.WHITE):fg,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(12),dp(13),dp(12),dp(13));b.setBackground(shape(primary?accent:surface,primary?0:border,12));b.setMinHeight(dp(48));b.setClickable(true);b.setFocusable(true);b.setOnClickListener(v->action.run());b.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN)v.setAlpha(.7f);if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL)v.setAlpha(1);return false;});return b;}
    protected TextView button(int resource,boolean primary,Runnable action){return button(getString(resource),primary,action);}
    protected void pair(LinearLayout parent,TextView a,TextView b){LinearLayout r=row();LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMarginEnd(dp(5));r.addView(a,p);LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,-2,1);q.setMarginStart(dp(5));r.addView(b,q);parent.addView(r);}
    protected LinearLayout card(LinearLayout parent){LinearLayout c=column();c.setPadding(dp(16),dp(16),dp(16),dp(16));c.setBackground(shape(surface,border,16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(12);parent.addView(c,p);return c;}
    protected void paragraph(LinearLayout parent,String value){TextView t=text(value,13,muted,false);t.setTextIsSelectable(true);parent.addView(t);gap(parent,12);}
    protected void paragraph(LinearLayout p,int r){paragraph(p,getString(r));}
    protected void section(LinearLayout p,int r){gap(p,16);p.addView(text(r,17,fg,true));gap(p,12);}
    protected LinearLayout scroll(LinearLayout parent){ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);LinearLayout content=column();content.setPadding(0,dp(10),0,dp(14));scroll.addView(content);parent.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));return content;}
    protected EditText input(LinearLayout parent,String label,String value){parent.addView(text(label,12,muted,true));gap(parent,6);EditText edit=new EditText(this);edit.setText(value);edit.setTextSize(14);edit.setTextColor(fg);edit.setHintTextColor(muted);edit.setSingleLine(true);edit.setBackground(shape(surface,border,10));edit.setPadding(dp(12),dp(10),dp(12),dp(10));parent.addView(edit,new LinearLayout.LayoutParams(-1,dp(48)));gap(parent,12);return edit;}
    protected Spinner select(LinearLayout parent,int label,String[] options){parent.addView(text(label,12,muted,true));Spinner spinner=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,options){public View getView(int p,View convert,android.view.ViewGroup group){TextView t=(TextView)super.getView(p,convert,group);t.setTextColor(fg);t.setTextSize(14);return t;}};spinner.setAdapter(adapter);spinner.setBackground(shape(surface,border,10));parent.addView(spinner,new LinearLayout.LayoutParams(-1,dp(48)));gap(parent,12);return spinner;}
    protected void item(LinearLayout parent,String glyph,String title,String subtitle,Runnable action){LinearLayout c=card(parent);LinearLayout row=row();TextView icon=text(glyph,21,accent,true);icon.setGravity(Gravity.CENTER);icon.setBackground(shape(dark?Color.parseColor("#203B39"):Color.parseColor("#E5F3EE"),0,12));row.addView(icon,new LinearLayout.LayoutParams(dp(44),dp(44)));LinearLayout lines=column();lines.setPadding(dp(14),dp(2),dp(8),0);lines.addView(text(title,15,fg,true));if(subtitle!=null&&!subtitle.isEmpty()){gap(lines,5);lines.addView(text(subtitle,11,muted,false));}row.addView(lines,new LinearLayout.LayoutParams(0,-2,1));TextView chevron=text("›",24,muted,false);row.addView(chevron);c.addView(row);c.setClickable(true);c.setFocusable(true);c.setOnClickListener(v->action.run());}
    protected void alert(String title,String message){new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton(R.string.close,null).show();}
    protected void confirm(String title,String message,Runnable yes){new AlertDialog.Builder(this).setTitle(title).setMessage(message).setNegativeButton(R.string.cancel,null).setPositiveButton(R.string.confirm,(d,w)->yes.run()).show();}
    protected void toast(int r){Toast.makeText(this,r,Toast.LENGTH_SHORT).show();}
    protected <T> void work(Work<T> operation,Done<T> done){progress=ProgressDialog.show(this,null,getString(R.string.working),true,false);forge.io.execute(()->{try{T result=operation.run();runOnUiThread(()->{if(progress!=null)progress.dismiss();if(isFinishing()||isDestroyed())return;try{done.accept(result);}catch(Exception e){failure(e);}});}catch(Exception e){forge.log("ERROR "+e.getClass().getSimpleName()+": "+e.getMessage());runOnUiThread(()->{if(progress!=null)progress.dismiss();if(!isFinishing()&&!isDestroyed())failure(e);});}});}
    protected void failure(Exception e){alert(getString(R.string.error),e.getMessage()==null?e.getClass().getSimpleName():e.getMessage());}
    protected void choose(String[] mime,Done<Uri> result){picker=result;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType(mime.length==1?mime[0]:"*/*");i.addCategory(Intent.CATEGORY_OPENABLE);if(mime.length>1)i.putExtra(Intent.EXTRA_MIME_TYPES,mime);startActivityForResult(i,410);}
    protected void chooseFolder(Done<Uri> result){picker=result;startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE),410);}
    protected void export(String name,String mime,Exporter callback){exporter=callback;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime);i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,420);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();if(request==410&&picker!=null){Done<Uri> chosen=picker;picker=null;try{chosen.accept(uri);}catch(Exception e){failure(e);}}if(request==420&&exporter!=null){Exporter callback=exporter;exporter=null;work(()->{try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("Output provider unavailable");callback.write(out);}forge.log("EXPORT completed");return true;},v->toast(R.string.saved));}}
    protected File cacheUri(Uri uri)throws Exception{File file=File.createTempFile("import-",".bin",getCacheDir());try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(file)){if(in==null)throw new IOException("Input provider unavailable");SafeFiles.copy(in,out,SafeFiles.MAX_PROJECT);}catch(Exception e){file.delete();throw e;}return file;}
    protected String uriName(Uri uri){try(android.database.Cursor c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}return "imported-file";}
    protected void openProject(String id){Intent i=new Intent(this,ProjectActivity.class);i.putExtra("id",id);startActivity(i);}
    protected void openEditor(String id,String path,int line){Intent i=new Intent(this,EditorActivity.class);i.putExtra("id",id);i.putExtra("path",path);i.putExtra("line",line);startActivity(i);}
}
